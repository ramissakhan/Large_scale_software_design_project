/**
 * studentAssignment.jsx
 * 
 * navigation component for the assignment page. displays all assignments, along with due dates and
 * completion status.
 * 
 * Version: 6/3/25
 * Author: Elise Heater
 */

import { Link } from 'react-router-dom';
import "./studentAssignments.css"


function StudentAssignments({assignmentArr}) {
    return (
    <div className="class-nav-wrapper">
        <div>
            <Link to="/studentDash">
              <button className='back'>Back to Dashboard</button>
            </Link>
        </div>
        <div className="class-tab">All Assignments</div>
        <ul className="class-list">
          {assignmentArr.map((assignmentName, index) => (
            <li className="class-item" key={index}>
              <Link to="/uploadPage">
                <button className="class-button">{assignmentName.name}</button>
              </Link>
              <li className='desc'>{assignmentName.description}</li>
              <li>submission deadline: {(assignmentName.submission_deadline).split("Z").join(" ").split("T").join(", ")}</li>
              <li>commenting deadline: {(assignmentName.commenting_deadline).split("Z").join(" ").split("T").join(", ")}</li>
            </li>
          ))}
        </ul>
      </div>
    )
}

export default StudentAssignments;
