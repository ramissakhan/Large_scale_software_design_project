/**
 * AssignmentPage.jsx
 * 
 * main component to display the assignment page for a user. This is where they can access individual projects
 * and assignments.
 * 
 * Version: 6/3/25
 * Author: Elise Heater
 */

import { useEffect, useState } from "react";
import StudentAssignments from "./studentAssignments";


function AssignmentPage({classId, studentId, className}) {

    const getAssignments = async (setAssignments, classId) => {
        const url = "http://127.0.0.1:8000/api/classes/" + classId + "/assignments/";
        const response = await fetch(url);
        if (!response.ok) {
            throw new Error(`Response status: ${response.status}`);
        }
        const json = await response.json();
        setAssignments(json);
    }

    const[assignments, setAssignments] = useState([]);

    useEffect(() => {
        getAssignments(setAssignments, classId);
    }, [classId]);


    return (
        <div className="dash-page">
          <div className="dash-header">
            <h1>{className}</h1>
          </div>
          <div className="dash-body">
            {<StudentAssignments assignmentArr={assignments}/>}
          </div>
        </div>
    );
}

export default AssignmentPage;
