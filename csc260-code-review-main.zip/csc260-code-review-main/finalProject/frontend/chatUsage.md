5/25/25
-Asked for advice on how to struture a code-viewing class and examples of communicating with the backend, specifically regarding keeping comments in the backend:
 eg. loading comments from the backend simultaneously while the page is setting up
 useEffect(() => {
    const fetchComments = async () => {
      try {
        const response = await fetch(`/api/comments?documentId=${documentId}`);
        const data = await response.json();
        setComments(data); // assume shape: { 0: "comment", 3: "another comment", ... }
      } catch (err) {
        console.error('Error loading comments', err);
      } finally {
        setLoading(false);
      }
    };


5/26/2025 
Asked for help with comment box how to make "Write your comment..." dissapear once the user started typing. 
This is what it helped me get to:
onChange= {(e) => setNewComment(e.target.value)}
        placeholder="Write your comment..."

5/28/2025
Asked ChatGPT for help with getting rid of my dark mode setting that was messing with the visuals of the webpage
only on my machine. It lead me to adding the following to the App.css
@media (prefers-color-scheme: dark) {
  body {
    background-color: white !important;
    color: black !important;
  }
}

This worked and was very helpful to use

6/1/25
I asked chat to explain the error messages I was getting when I was trying to POST things to the backend and it helped me correctly format my posting so that I can actually communicate and redirected me to check out the terminal in the browser which was quite helpful.

6/4/25
I used chat to help debug my code based off of the error messages in my browser console. I couldn't find where I was causing an infinite loop and how to stop it. 
