/*
    codeBox.jsx
    This is the component where the the given person's code is 
    displayed and one can highlight and comment on it.

    Version: June 6, 2025
    Author: S. Pegolo, R. Kolodziejczyk, R. Khan
*/

import { useState, useEffect } from 'react';
import './CodeStyle.css';

const LINEADJUSTMENT = 1; // adjustment for line numbers when commenting

// takes in the comments, and can send back setComments so the comments can be 
// specific to certain code blocks (each person)
function CodeBox({ id }) {
  // State to track which line is currently selected
  const [selectedLine, setSelectedLine] = useState(null);

  // Temporarily holds the text of the new comment being written
  const [newComment, setNewComment] = useState('');
  
  const [comments, setComments] = useState({});
  const [code, setCode] = useState("");
  const [docId, setDocId] = useState(null);

  //gets the code, comments, etc for the student user id passed in 
  useEffect(() => {
  async function getDocInfo() {
      try {
        console.log(id);
        const response = await fetch(`http://127.0.0.1:8000/api/assignments/2/submissions/?student=${id}`); //2 changes based off of assignment and id is only student id currently
        if (!response.ok) {
          throw new Error(`Response status: ${response.status}`);
        }
        const json = await response.json();
        setCode(json[0].files[0].content); 
        setDocId(json.id);
        const commentSetUp = json[0].comments.reduce((acc, element) => {
          const line = element.line_number;
          if (!acc[line]) {
            acc[line] = []; 
          }
          acc[line].push(element.comment); 
          return acc;
        }, {});
        setComments(commentSetUp);
        console.log(commentSetUp);
      } catch (error) {
        console.error("Error:", error);
      }
    }
    getDocInfo();
    setNewComment('');
    setSelectedLine(null);
  }, [id]);

  //formatted the code
  const formattedCode = code;
  const lines = formattedCode.split('\n');

  // Called when a line is clicked. Sets the selected line and pre-fills the comment box if one exists
  const handleLineClick = (index) => {
    setSelectedLine(index);
    setNewComment('');
  };

  // Handles submitting a comment: updates the comments object and clears selection
  const handleSubmit = () => {
    if (newComment.trim() === '') return; // don't allow empty comments
    setComments({...comments, [selectedLine]: [...(comments[selectedLine] || []), newComment]});
    const data = {
      submission: docId,
      submission_file: docId,
      line_number: selectedLine,
      user: 17, //change to user eventually
      comment: newComment
    };

    //posts the comments to the backend
    fetch('http://127.0.0.1:8000/api/addcomment/',{
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(data)
    })
    .then(response => {
    if (response.ok) { 
      return response.json(); 
    } else {
      throw new Error('Request failed.');
    }
  })
  .then(responseData => {
    console.log('Success:', responseData);
  })
  .catch(error => {
    console.error('Error:', error);
  });
    setSelectedLine(null); // hide the comment box
    setNewComment('');     // clear input field
  };

  if (lines === '') {
    return <div>Loading...</div>;
  }

  return (
    <>
      <div className="label-row">
        <div className="label-block">Student Code</div>
        <div className="label-block">Comments</div>
      </div>
  
      <div className="code-wrapper">
        {/* Main code viewer box */}
        <div className="code-container">
          {lines.map((line, index) => {
            const hasComment = comments[index];
            const isSelected = selectedLine === index;
  
            let classList = ['code-line'];
            if (hasComment) classList.push('has-comment');
            if (isSelected) classList.push('selected');
  
            return (
              <div
                key={index}
                className={classList.join(' ')}
                onClick={() => handleLineClick(index)}
              >
                <span className="line-number">{index + LINEADJUSTMENT}</span>
                <span className="line-content">{line}</span>
              </div>
            );
          })}
        </div>
  
        {/* Sidebar panel for writing and viewing comments */}
        <div className="comment-panel">
          {selectedLine !== null && (
            <div>
              <h4>Comments on Line {selectedLine + LINEADJUSTMENT}</h4>
              <textarea
                className="comment-input"
                value={newComment}
                onChange={(e) => setNewComment(e.target.value)}
                placeholder="Write your comment..."
              />
              <button className="submit-btn" onClick={handleSubmit}>
                Submit
              </button>
            </div>
          )}
  
          {/* Show all submitted comments */}
          {(() => {
            if (selectedLine !== null) {
              if (comments[selectedLine] && comments[selectedLine].length > 0) {
                return (
                  <div className="all-comments-scroll">
                    {comments[selectedLine].map((comment, idx) => (
                      <div key={idx} className="comment-item">
                        {comment}
                      </div>
                    ))}
                  </div>
                );
              }
            } else {
              return (
                <div className="no-line-selected">
                  <p>Click on a line of code to view previous comments and to leave feedback!</p>
                </div>
              );
            }
          })()}
        </div>
      </div>
    </>
  );
}  


export default CodeBox;