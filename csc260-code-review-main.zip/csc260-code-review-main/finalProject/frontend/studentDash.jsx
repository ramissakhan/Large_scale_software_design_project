/**
 * studentDash.jsx
 * 
 * Main component for the student dashboard page. This will display the student's current classes
 * and the assignments for those classes. Also makes sure a student is trying to view this.
 * 
 * Author: Elise Heater, Ryan Kolodziejczyk
 * Version: 6/1/25
 * 
 */
import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import ClassNav from "./classNav";
import "./studentDash.css";

function StudentDash({studentId}) {

    //getter functions for backend
    const getClassNames = async (setClassNames, studentId) => {
        const url = "http://localhost:8000/api/classes/?student=" + studentId;
        const response = await fetch(url);
        if (!response.ok) {
            throw new Error(`Response status: ${response.status}`);
        }
        const json = await response.json();
        const namesDict = Object.fromEntries(json.map((name) => [name.code + ": " + name.name, name]));
        setClassNames(namesDict);
    }

    const getUserName = async (setUserName, studentId) => {
        const url = "http://localhost:8000/api/users/" + studentId + "/";
        const response = await fetch(url);
        if (!response.ok) {
            throw new Error(`Response status: ${response.status}`);
        }
        const json = await response.json();
        if (!json.is_teacher) {
            setUserName(json.name);
        } 
    }

    useEffect(() => {
        getClassNames(setClasses, studentId);
    }, []);

    useEffect(() => {
        getUserName(setUserName, studentId);
    }, []);

    const [user, setUserName] = useState();
    const [classes, setClasses] = useState({});
    // only want the class names
    const classNames = Object.keys(classes);

    if (!user) {
        return (
            <div className = "dash-page">
                <div className = "dash-header">
                    <h1>You are not a student, please return to the login page</h1>
                </div>
                <Link to="/">
                  <button className="login-button">Return to Login</button>
                </Link>
            </div>
        );
    }

    else {
      return (
          <div className="dash-page">
            <div className="dash-header">
              <h1>Welcome, {user}!</h1>
            </div>
            <div className="dash-body">
              <ClassNav classList={classNames} studentId={studentId} />
            </div>
          </div>
        ); 
    }
}

export default StudentDash;