/**
 * Upload page
 * 
 */

function Upload() {
    return (
        <div>
            <h1>Code Upload</h1>
            <button onClick={() => setCurrentPage(commentPage)}>Upload Code</button>
        </div>
    )
}

export default Upload;