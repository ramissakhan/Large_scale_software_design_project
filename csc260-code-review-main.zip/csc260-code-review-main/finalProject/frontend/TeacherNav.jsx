import { useEffect, useState } from "react";
import AssignmentNav from './AssignmentNav';
import "./classNav.css";

/**
 * TeacherNav.jsx
 * 
 * Class navigation component for the student/teacher dashboard. 
 * Displays active classes, links to the teacher's assignment
 * page when a class is clicked.
 * 
 * Using classNav.css to make it look consistent
 * 
 * Author: Ryan Kolodziejczyk
 * Version: 6/3/25
 * 
 */

function TeacherNav({ teacherId }) {
    const [classData, setClassData] = useState([]);
    const [selectedClassId, setSelectedClassId] = useState(null);
    const [selectedClassName, setSelectedClassName] = useState(null);

    useEffect(() => {
    if (!teacherId) {
        setClassData([]);
        return;
    }

    const url = `http://localhost:8000/api/classes/?teacher=${teacherId}`;
    fetch(url)
        .then((res) => {
        if (!res.ok) {
            throw new Error(`Failed to fetch classes (status ${res.status})`);
        }
        return res.json();
        })
        .then((data) => {
        // data is an array of class objects
        // [ {class1}, {class2}, … ]

        const mapped = data.map((cls) => ({
            id: cls.id,
            label: `${cls.term} ${cls.year}: ${cls.name}`,
        }));
        setClassData(mapped);
        })
    }, [teacherId]);

    return (
        <div className="class-nav-wrapper">
            <div className="class-tab">Classes Taught</div>
            <ul className="class-list">
            {classData.map((cls) => (
                <li className="class-item" key={cls.id}>
                <button
                    className="class-button"
                    onClick={() => (
                        setSelectedClassId(cls.id),
                        setSelectedClassName(cls.label)
                    )}>
                    {cls.label}
                </button>
                </li>
            ))}
            </ul>

            {selectedClassId && (
            <div className="assignments-container">
                <AssignmentNav courseName = {selectedClassName} courseId = {selectedClassId} />
            </div>
            )}
        </div>
    );
}

export default TeacherNav;