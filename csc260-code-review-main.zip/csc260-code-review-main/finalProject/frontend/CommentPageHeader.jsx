/* 
    CommentPageHeader.jsx

    This is the header component for the comment page. It displays the 
    group name/number (if applicable) and members.

    Version: May 27, 2025
    Author: R. Kolodziejczyk, S. Pegolo
*/

import { capitalize } from "./util";
import { useState, useEffect } from "react";
import './CommentPageHeader.css';

function CommentPageHeader({ groupName, members }) {
    const [names, setNames] = useState(null);
  
    //grabbing the group members' names from the backend given their ids
    useEffect(() => {
      async function fetchUser() {
        try {
          const namePromises = members.map(async (id) => {
            const response = await fetch(`http://127.0.0.1:8000/api/users/${id}/`);
            const json = await response.json();
            return json.name;
          });

          const names = await Promise.all(namePromises); 
          setNames(names);
        } catch (err) {
          console.error("Error fetching user names:", err);
        }
      }
      fetchUser();
    }, [members]);

  if (names === null) {
    return <div>Loading...</div>;
  }

  return (
    <div className="comment-page-header">
      <h1>{capitalize(groupName)} Code Commenting</h1>
      <h2>{groupName}: {names.map(capitalize).join(', ')}</h2>
    </div>
  );
}

export default CommentPageHeader;