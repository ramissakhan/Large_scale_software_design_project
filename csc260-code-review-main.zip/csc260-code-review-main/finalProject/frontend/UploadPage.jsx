/*
	UploadPage.jsx
	This is the page where the students can upload code

	Version: May 28 2025
	Author: E. Heater, R. Kolodziejczyk, R. Khan
*/


import './UploadPage.css';
import { Link } from 'react-router-dom';

function UploadPage() {
  return (
    <div className="upload-page">
      <div className="upload-header">
        <h1>Upload Your Code Here</h1>
      </div>
      <div className="upload-body">
        <div className="drop-zone">
          Drag and drop your files here
        </div>
        <Link to="/commentPage">
          <button className="upload-button">Upload Code</button>
        </Link>
      </div>
    </div>
  );
}

export default UploadPage;

