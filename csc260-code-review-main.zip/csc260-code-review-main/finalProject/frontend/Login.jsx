/*
  Login.jsx
  This is the page where the user has the option to chose
  to enter the app as a student or teacher

  Author: S. Pegolo, R. Kolodziejczyk, R. Khan
  Version: May 27 2025
*/
import { Link } from 'react-router-dom';
import './Login.css';

const loginButtonLinks = {
    "teacher": "/teacherHome",
    "student": "/studentDash",
}

function Login({ setUser }) {
  //current hard-coded student and teacher for a working prototype version  
  const userTypes = [["teacher", 2], ["student", 17]];

  //setting up the buttons for user and student (could eventually sign in with email and get role based off of that)
    const listItems = userTypes.map(item =>
        <li className = "person-item" key={item[0]}>
            <Link to={loginButtonLinks[item[0]]}>
                <button className="person-button" onClick={() => setUser(item[1])}>
                    I am a {item[0]}
                </button>
            </Link>
        </li>
    );

    return (
        <div className="login-page">
          <div className="login-header">
            <h1>Welcome!</h1>
            <h2> Choose your role to get started: </h2>
          </div>
          <div className="login-body">
            <ul className="person-list">{listItems}</ul>
          </div>
        </div>
      );       
};


export default Login; 