import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import TeacherNav from "./TeacherNav";
import "./TeacherHome.css";

/**
 * TeacherHome.jsx
 * 
 * This is the wrapper for both the TeacherNav and AssignmentNav.
 * Displays the banner at the top with the teacher's name, as well
 * as calls TeacherNav with the classList of the classes the teacher
 * is currently teaching. It also makes sure a teacher is trying to
 * open the teacher home.
 *  
 * Author: Ryan Kolodziejczyk
 * Version: 6/3/25
 */

function TeacherHome({ teacherId }) {
    const [userName, setUserName] = useState("");
    const [classes, setClasses] = useState({});

    // getting the teacher’s user record, verify is_teacher, then set the name.
    const getUserName = async (setUserName, teacherId) => {
        const url = `http://localhost:8000/api/users/${teacherId}/`;
        const response = await fetch(url);
        if (!response.ok) {
            console.error(`Failed to fetch user: ${response.status}`);
            return;
        }
        const json = await response.json();
        
        // userName is only set if the user is a teacher
        if (json.is_teacher) {
            setUserName(json.name);
        } 
    };

    // getting all classes taught by this teacher
    const getClassNames = async (setClassNames, teacherId) => {
        const url = `http://localhost:8000/api/classes/?teacher=${teacherId}`;
        const response = await fetch(url);
        if (!response.ok) {
            console.error(`Failed to fetch classes: ${response.status}`);
            return;
        }
        const json = await response.json();

        // Build a { "CODE: Name": classObject } mapping, same as studentDash
        const namesDict = Object.fromEntries(
            json.map((cls) => [`${cls.term} ${cls.year}: ${cls.name}`, cls])
        );
        setClassNames(namesDict);
    };

    useEffect(() => {
    if (teacherId) {
        getUserName(setUserName, teacherId);
        getClassNames(setClasses, teacherId);
    }}, [teacherId]);

    const classNames = Object.keys(classes);

    if (!userName) {
        return (
            <div className = "dash-page">
                <div className = "dash-header">
                    <h1>You are not a teacher, please return to the login page</h1>
                </div>
                <Link to="/">
                  <button className="login-button">Return to Login</button>
                </Link>
            </div>
        );
    }

    else {
        return (
            <div className = "dash-page">
                <div className = "dash-header">
                    <h1>Welcome, {userName}!</h1>
                </div>
                <div className = "dash-body">
                    <TeacherNav classList={classNames} teacherId={teacherId} />
                </div>
            </div>
        );
    }
}

export default TeacherHome;
