/**
 * classNav.jsx
 * 
 * Class navigation component for the student/teacher dashboard. Displays active classes, links to class
 * pages when they are clicked on.
 * 
 * Author: Elise Heater, Ramissa Khan
 * Version: 6/2/25
 * 
 */

import { Link } from 'react-router-dom';
import "./classNav.css";

function ClassNav({ classList , studentId}) {
    return (
      <div className="class-nav-wrapper">
        <div className="class-tab">Enrolled Classes</div>
        <ul className="class-list">
          {classList.map((className, index) => (
            <li className="class-item" key={index}>
              <Link to="/assignmentPage">
                <button className="class-button">{className}</button>
              </Link>
            </li>
          ))}
        </ul>
      </div>
    );
  }

export default ClassNav;