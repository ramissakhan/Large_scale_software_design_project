import { useState } from 'react'
import './App.css'
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Login from './Login.jsx';
import CommentPage from './commentPage.jsx';
import UploadPage from './UploadPage.jsx';
import ClassNav from './classNav.jsx';
import StudentDash from './studentDash.jsx';
import TeacherHome from './TeacherHome.jsx';
import AssignmentPage from './assignmentPage.jsx';


const group = 1;
const mockId = 17;

function App() {
  const [user, setUser] = useState(17); //if we want to pass users eventually


  return (
    // <AssignmentPage classId={2} studentId={mockId} className={"test"}/>
    <Router>
      <Routes>
        <Route path = "/" element = {<Login setUser={setUser}/>} />
        <Route path = "/commentPage" element = {<CommentPage group={group}/>} />
        <Route path = "/uploadPage" element = {<UploadPage />} />
        <Route path = "/studentDash" element = {<StudentDash studentId = {user}/>}/>
        <Route path = "/teacherHome" element = {<TeacherHome teacherId = {user}/>} />
        <Route path = "/assignmentPage" element = {<AssignmentPage classId={2} studentId={mockId} className={"CSC 260"}/>} />
      </Routes>
    </Router>
  );
}


export default App;
