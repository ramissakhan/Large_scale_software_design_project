/*
  personNav.jsx
  This is the navigation bar component for commentPage.jsx. It will display all team members' names,
  along with the instructor. When a name is clicked on, code.jsx will display that person's code.

  Version: May 27 2025
  Author: E. Heater, R. Kolodziejczyk, S. Pegolo
*/

import { capitalize } from "./util";
import { useState, useEffect } from "react";
import "./PersonNav.css";



function PersonNav({group, setPersonCode}) {
    const [names, setNames] = useState(null);
  
    //get the group members names and ids
    useEffect(() => {
      async function fetchUser() {
        try {
          const namePromises = group.map(async (id) => {
            const response = await fetch(`http://127.0.0.1:8000/api/users/${id}/`);
            const json = await response.json();
            return [id, json.name];
          });

          const names = await Promise.all(namePromises); 
          setNames(names);
        } catch (err) {
          console.error("Error fetching user names:", err);
        }
      }
      fetchUser();
    }, [group]);

    if (names === null) {
        return <div>Loading...</div>;
    }

    //make buttons with names for navigation
    const listItems = names.map((item) =>
        <li className = "person-item" key={item[1]}>
        <button onClick={() => {setPersonCode(item[0])}}>
            {capitalize(item[1])}
        </button>
        </li>
    );

    return (
        <div className="person-nav">
          <h3 className="person-label">Group Members</h3>
          <ul className="person-list">
            {listItems}
          </ul>
        </div>
      );      
}

export default PersonNav;