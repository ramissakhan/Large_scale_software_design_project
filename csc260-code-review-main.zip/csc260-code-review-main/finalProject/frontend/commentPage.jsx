/*
  commentPage.jsx
  This is the main component for the comment interface of the group code review tool.
  It manages which the header section with the group name, the person list of the group members,
  which person's code is being viewed, and the comment data associated with that code block.
  This is the hub for the entire page.

  Version: June 5 2025
  Author: R. Kolodziejczyk, S. Pegolo
*/

import { useState, useEffect } from 'react'
import './App.css'
import CommentPageHeader from './CommentPageHeader.jsx';
import CodeBox from './codeBox.jsx';
import PersonNav from './personNav.jsx';


function CommentPage({ group }) {
  // state variable to show which code is being shown in box, use first member as default
  const [selectedPerson, setSelectedPerson] = useState(null);
  const [groupMemberIds, setGroupMemberIds] = useState(null);

  //gets the ids of all the members in the group
  useEffect(() => {
    async function getMembers() {
      try {
        const response = await fetch(`http://127.0.0.1:8000/api/groups/${group}/`);
        if (!response.ok) {
          throw new Error(`Response status: ${response.status}`);
        }
        const json = await response.json();
        const allMembers = json.users.map(user => user.id); 
        setGroupMemberIds(allMembers); 
        console.log(allMembers);
      } catch (error) {
        console.error("Error fetching group members:", error);
      }
    }
    getMembers();
  }, [group]);

  //set the default person to the first in the group
  useEffect(() => {
    if (groupMemberIds && selectedPerson === null) {
      setSelectedPerson(groupMemberIds[0]);
    }
  }, [groupMemberIds, selectedPerson]);


  if (!groupMemberIds || selectedPerson === null) {
    return <div>Loading...</div>;
  }


  return (
    <div className="comment-page">
      <div>
        <CommentPageHeader groupName = "Group 1" members = {groupMemberIds} />
      </div>
      <div className = "column-container">
        <PersonNav group = {groupMemberIds} setPersonCode = {setSelectedPerson} />
        <div className="code-section">
          <div className="comment-section">
            <CodeBox id = {selectedPerson} />
          </div>
        </div>
      </div>
    </div>
  );
}

export default CommentPage;