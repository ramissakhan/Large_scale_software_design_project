import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import "./classNav.css";

/**
 * AssignmentNav.jsx
 * 
 * This is the dropdown that shows all of the assignments for a class.
 * When clicked, it hsows a list of the assignment names. Clicking on
 * an assignment name will take the user to the comment page.
 * 
 * Right now it is just sent to the general comment page, we can make it 
 * specialized later.
 * 
 * Using classNav.css to make it look consistent
 * 
 * Author: Ryan Kolodziejczyk
 * Version: 6/3/25
 * 
 */

function AssignmentNav({ courseName, courseId }) {
  const [assignmentNames, setAssignmentNames] = useState([]);

  useEffect(() => {
    if (!courseId) {
      setAssignmentNames([]);
      return;
    }

    fetch(`http://127.0.0.1:8000/api/classes/${courseId}/assignments/`)
      .then((res) => {
        if (!res.ok) {
          throw new Error(`Failed to fetch assignments (status ${res.status})`);
        }
        return res.json();
      })
      .then((data) => {
        // data is an array of assignment objects
        // [ {assignment1}, {assignment2}, … ]

        const names = data.map((assignment) => ({
          id: assignment.id,
          name: assignment.name,
        }));
        setAssignmentNames(names);
      })
  }, [courseId]);

  return (
    <div className="class-nav-wrapper">
      <div className="class-tab">Assignments for {courseName}</div>
      <ul className="class-list">
        {assignmentNames.map((assignment, index) => (
          <li className="class-item" key={assignment.id || index}>
            <Link to={`/commentPage`}>
              <button className="class-button">
                {assignment.name}
              </button>
            </Link>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default AssignmentNav;