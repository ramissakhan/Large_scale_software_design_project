**List of Backend Endpoints**
1. /api/users/id
- so we know who the user is and can display certain things based on their id, example: 1234 (string)
2. /api/users/is_teacher
- shows us whether user is teacher or student, example: true (boolean)
3. /api/users/name
- shows us who the user is, example: heatere (string)
4. /api/classes/name
- shows us which classes are on dashboard, need it to differentiate, example: CSC106 (string)
5. /api/classes/assignments/name
- gives the assignment names so we can list them out, example: project 1 (string)
6. /api/classes/assignments/submission_deadline
- need to know so we can display the deadline, example: 11:59 PM (timestamp)
7. /api/classes/assignments/commenting_deadline
- need to know so we can display deadline and show status, example: 11:59 PM (timestamp)
8. /api/classes/assignments/assignment_submissions/submitted_at
- want to know so we can compare with deadline and see whether entry is late, example: 12:01 AM (timestamp)
9. /api/classes/assignments/assignment_submissions/assignment_submission_files/content
- to display the submitted code, example: file of code (pdf, doc, etc)
10. /api/classes/assignments/assignment_submissions/assignment_submission_comments/comment
- so we can display the comment, example: this a comment (string)
11. /api/classes/assignments/assignment_submissions/assignment_submission_comments/line_number
- to figure out which comment we are looking at and where it is, example: 4 (int)
12. /api/classes/assignments/assignment_submissions/assignment_submission_comments/submission_file_id
- we want to see a specific person's code, example: 0000 (string)
