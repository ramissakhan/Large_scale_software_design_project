# csc260-code-review 
# Group Name: err.js 

**About**
This website is an unfinished, but fully working demo for a code commenting application. Our goal was to create something that allowed teachers to upload a roster for their class, create assignments with student groups, and see their students' progress on those assignments. The students would then be able to upload code for their assignments and comment on their groupmates' code. We were unable to fully implement many of these aspects; there is no functioning upload, the teacher cannot create a class, there is no authentication/login, just to name a few. But it is, after all, just a demo, so it is simply a starting point to build off of. 
---
**How to Run the Website**
 - Open terminal in IDE
 - navigate to the folder that your Python Virtual Environment is stored in (you need to install one if you dont have it)
 - Make that the source (source ..pathTo/bin/activate/)
 - cd back to the project BACKEND folder, run python manage.py runserver (NOTE: the backend must be running for the website to work properly)
 - now open a new terminal, navigate to the FRONTEND folder, type npm run dev
 - the link to the website should now be available
---
**Implementation Structure**
        The implemenation is heavily based off of react assignments we did in class; it uses react, along with a Django database, which we only had practice with from the past few assignments. Each page has multiple react components, for example, the navBar on the class pages and dashboards is a seperate component from the rest of the page. They also fetch data from the database, so any changes made will need to take that into account. It is also very easy to make additions to the database using the admin interface. We also used react routers to route to each different page. 
