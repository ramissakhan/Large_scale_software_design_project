# Team Contract

Within your group, agree on a group contract that will govern your collaboration. The contract should spell out the behaviors you expect of all group members, as well as procedures for resolving impasses in the group.

Specific questions to think about include the following:

* What is our level of ambition for this project?
- Our Best Effort - High level of ambition. 

* How will we communicate with each other?
- Through text. 

* How often and where will we meet?
- Twice a week: Mondays & Wednesdays anytime from 3-6 PM 

* Who is the Product Owner and who is the Scrum Facilitator/Master for each milestone? (I suggest that you rotate the role of the scrum facilitator.)
- Product Owner: Sophia Pegolo
- Scrum Facilitator: Ramissa, Elise, Ryan, and Justin. 

* How will we make sure that our meetings are productive?
- Set weekly goals. Stick to the guideline of what you did the previous week, what you will work on moving forward, any questions/concerns, and any new ideas. 

* Once we start implementing, how are we going to manage our git repository?
- Each person should branch it seperately and wait to push until the group meeting. 

* What will we do if some team member contributes significantly less than others?
- Ask them if everything is okay, if they need help with their work, and help them get through any issues and work together to find a solution. 

* What will we do if some team member violates any agreements in this contract?
- Communicate with them, come to a solution that makes everyone happy, if it comes to it include Kristina. 

Each team member should signal their agreement with this contract by adding their name at the bottom.
x Ramissa Khan, Elise Heater, Sophia Pegolo, Ryan Kolodziejczyk, Justin Schulte

**Appendix**
- We have very strong communication and can collaborate efficiently
- We're concerned about individual/group mental and physical presence during our meetings and with class presentations
